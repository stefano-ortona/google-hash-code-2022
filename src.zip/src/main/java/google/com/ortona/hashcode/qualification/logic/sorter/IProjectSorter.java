package google.com.ortona.hashcode.qualification.logic.sorter;

import google.com.ortona.hashcode.qualification.model.Project;

import java.util.List;

public interface IProjectSorter {

    public void sortProject(List<Project> projectList);

}
